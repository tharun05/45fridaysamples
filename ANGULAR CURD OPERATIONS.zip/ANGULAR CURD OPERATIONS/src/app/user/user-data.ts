import { User } from './user';

export const USER_PERSONS: User[] = [{
    id: 1,
    name: 'Scissors'
    
  }, {
    id: 2,
    name: 'Steak Knives'
  }, {
    id: 3,
    name: 'Shot Glass',

  }]